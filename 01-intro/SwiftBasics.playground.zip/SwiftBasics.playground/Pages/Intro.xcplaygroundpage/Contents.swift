/*:
 
# Swift Basics

This playground demonstrates basic usage of Swift.
 
You are encouraged to poke around, change different parts of code and observe the behavior.
 
Ask your mentor if not sure about anything!
 
If you don't like this view, you can switch it in main menu by choosing `Editor`/`Show raw markup`
 
_Part of STRV Academy course_

 
[Next](@next)
 
*/